// Functions that are defined in FastSpring's JS that need tweaking.

// tipPosition can return negative x and y values.
tipPosition = function (e, tip){
 		var tipWidth = tip.getWidth();
		var taskWidth = Ext.getBody().getWidth();
		var x = e.getPageX();
		var spacer = 12;
		if (x + spacer + tipWidth > taskWidth){
		  x = x - tipWidth - spacer;
		} else {
		  x = x + spacer;
		}
		
		y = e.getPageY() - (tip.getHeight() * .75);
		
		if (x < 0) {
			x = spacer;
		}
		if (y < 0) {
			y = spacer;
		}
		
		tip.setXY([x, y]);	 
}
